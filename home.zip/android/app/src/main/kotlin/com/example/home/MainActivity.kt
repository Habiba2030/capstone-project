package com.example.home

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
