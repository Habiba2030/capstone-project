import 'package:flutter/material.dart';
import 'package:home/home_localbrand1.dart';
import 'package:home/signinpage.dart';

class Signupcollab extends StatefulWidget {
  const Signupcollab({super.key});

  @override
  State<Signupcollab> createState() => _SignupcollabState();
}

class _SignupcollabState extends State<Signupcollab> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'image/Super_Stars-removebg.png',
              height: 100,
            ),
            SizedBox(height: 20),

            Container(
              width: 500,
              child: Text(
                'Collab',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              ),
            ),
            Container(
              width: 500,
              child: Text(
                'Please collab to join.',
                style: TextStyle(fontSize: 16, color: Colors.black),
              ),
            ),

            SizedBox(height: 20),

            // Username TextField
            TextFormField(
              decoration: InputDecoration(
                labelText: 'Instagram Username',
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            SizedBox(height: 10),

            SizedBox(height: 20),

            // Sign up Button
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Home()));
              },
              child: Text(
                'Send us',
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFFFCDD2),
                  minimumSize: Size(double.infinity, 50)),
            ),

            SizedBox(height: 10),

            // Already have an account? Sign in
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Are you user?',
                  style: TextStyle(color: Colors.grey),
                ),
                GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => Signin(),
                          ));
                    },
                    child: Text('Sign in')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
