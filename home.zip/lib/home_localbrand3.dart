import 'package:flutter/material.dart';
import 'package:home/home_localbrand1.dart';
import 'package:home/home_localbrand2.dart';
import 'package:home/home_localbrand4.dart';
import 'package:home/home_localbrand5.dart';

class Home3 extends StatefulWidget {
  const Home3({super.key});

  @override
  State<Home3> createState() => _Home1State();
}

class _Home1State extends State<Home3> {
  final List<String> images = [
    'image/logo1.png',
    'image/logo2.png',
    'image/logo3.jpg',
    'image/logo2.png',
    'image/logo1.png',
  ];
  final List<Widget> pages = [
    Home(),
    Home2(),
    Home3(),
    Home4(),
    Home5(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFD6D6D6),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              child: TextFormField(
                decoration: InputDecoration(
                  hintText: 'Search Products',
                  prefixIcon: Icon(Icons.search, color: Colors.grey),
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: images.length,
                itemBuilder: (context, index) {
                  return Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: InkWell(
                        child: CircleAvatar(
                          backgroundImage: AssetImage(images[index]),
                          radius: 40,
                        ),
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => pages[index],
                              ));
                        },
                      ));
                },
              ),
            ),
            Row(
              children: [
                Column(
                  children: [
                    Container(
                        height: 150,
                        width: 250,
                        child: InkWell(
                          child: Image.network("image/t_shirt.png"),
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => Home2(),
                                ));
                          },
                        )),
                    SizedBox(height: 10), // Add spacing between image and text
                    Text(
                      "SG Pink",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      "LE 1,350.00 EGP",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Column(
                  children: [
                    Container(
                        height: 150,
                        width: 250,
                        child: InkWell(
                          child: Image.network("image/t_shirt.png"),
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => Home2(),
                                ));
                          },
                        )),
                    SizedBox(height: 10), // Add spacing between image and text
                    Text(
                      "Black G Tee",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      "LE 350.00 EGP",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 50,
            ),
            Row(
              children: [
                Column(
                  children: [
                    Container(
                        height: 150,
                        width: 250,
                        child: InkWell(
                          child: Image.network("image/t_shirt.png"),
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => Home2(),
                                ));
                          },
                        )),
                    SizedBox(height: 10), // Add spacing between image and text
                    Text(
                      "pink puff TEE",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      "LE 700.00 EGP",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: Colors.black,
          unselectedItemColor: Colors.pinkAccent,
          backgroundColor: Colors.redAccent,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
            BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
            BottomNavigationBarItem(icon: Icon(Icons.menu), label: "Browse"),
            BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart), label: "Cart"),
            BottomNavigationBarItem(
                icon: Icon(Icons.account_circle_outlined), label: "Account"),
          ]),
    );
  }
}
